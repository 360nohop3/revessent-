# The Idea Brief — "Revessent"

> **Historical note (2026-09-05):** This document records the concept as it was originally
> workshopped under the working name **Hearth**. The product shipped as **REVESSENT**;
> the body below is kept verbatim as the historical record — where it says Hearth, read Revessent.
> The live single-file build lives in `index.html`.

**One line:** Revessent is the revenue intelligence for for subscription businesses — an AI recovery concierge that turns failed payments into kept members and quietly upgrades your happiest customers before they ask.

**Tagline:** *Never lose another member to a failed card.*

---

## Why this is the million-dollar idea

### 1. The pain is money already lost — the most guilt-free spend in SaaS
Involuntary churn (customers who leave because a card silently declines — **not** because they want to) is estimated at **20–40% of all subscription churn** (ProfitWell / Recurly), and the average subscription business loses roughly **9–12% of MRR to it every year** ([1](https://ustechautomations.com/resources/blog/saas-dunning-automation-pain-solution-recover-70-percent)). 10–15% of recurring card payments fail outright (GoCardless, 52M transactions) ([2](https://www.payfacile.com/en/blog/subscription-commerce/reduce-failed-payments-churn)). A founder literally watches money walk out the door every week.

### 2. People are dying to pay because the ROI is visible in month one
Benchmarks are brutal and flattering at once:
- Median business recovers only **~47.6%** of failed payments (Baremetrics/Slicker) ([3](https://www.digitalapplied.com/blog/failed-payment-recovery-dunning-playbook-2026))
- No dunning automation: **20–31%** recovered; smart dunning stacks: **50–80%** (Chargebee 2025 benchmark) ([1](https://ustechautomations.com/resources/blog/saas-dunning-automation-how-to-recover-failed-payments))
- Stripe's *default* retries recover ~57% — the extra 15–25 points are what a specialist earns ([2](https://www.payfacile.com/en/blog/subscription-commerce/reduce-failed-payments-churn))
- Recovered subscribers stay an average of **7+ more months** (Stripe)

So the pitch writes itself: *"Pay us $299/mo; we'll recover $3–6k of MRR in your first 90 days or the term is free."* No tool in SaaS has a cleaner "it pays for itself" demo.

### 3. The market is proven and still consolidating
Dedicated recovery tools charge **$200–$800/mo or 1–5% of recovered revenue** (ChurnBuster, Baremetrics Recover, Butter Payments, Paddle Retain) ([4](https://ustechautomations.com/resources/blog/saas-best-payment-recovery-software-for-recipe-2026)) — and 44% of SaaS companies still have **no dedicated dunning process** beyond billing defaults ([1](https://ustechautomations.com/resources/blog/saas-dunning-automation-pain-solution-recover-70-percent)). The wedge: existing tools are dashboards and email templates — utility, not delight. Nobody has built the **beautiful, concierge-grade** version with AI-written human dunning, upgrade-moment expansion, and white-glove checkout. Category is validated; positioning is empty.

### 4. The "expansion" twist nobody pairs with recovery
Churn tools fight on the downside; growth tools fight on the upside. Hearth is the first to own both: recovery (**keep the MRR you have**) + **upgrade moments** (nudge power users to the right plan at the exact moment they hit a limit — 2× ARR potential per account). That's the real $1M ARR story, not just dunning.

### 5. Subscription dynamics are perfect
- **Mission-critical once wired in:** it holds your billing data, retry logic and customer emails. Switching costs are brutal — churn will be low.
- **Measurable outcome = price-insensitive buyer** (Head of Revenue, not a PM).
- **Low feature floor:** v1 needs Stripe read/write, smart retries, email + hosted checkout, decline-reason routing. Shippable by a small team in weeks.

---

## The math to $1M ARR

| Assumption | Value |
|---|---|
| Price points | $149 / $299 / $599 per month (+ free 14-day pilot) |
| Blended ARPA | ~$340/mo |
| Customers for $1M ARR | ~245 |
| Target ICP | Stripe-billed B2B SaaS, $25k–$2M MRR |
| Served market (est.) | Tens of thousands of Stripe-billed subscription businesses globally; plus Chargebee/Recurly via API |
| Realistic funnel | 1.5% of 60k monthly visitors → pilot; 45% pilot→paid; ~245 logos in ~24 months |

Guarantee makes it a no-brainer: **"If Hearth doesn't recover more than it costs you in your first 90 days, your next quarter is free."** A pay-for-outcome promise is the strongest close in B2B because our win-rate (50–80%) makes it profitable to offer.

---

## Why not the other candidates

| Idea | Verdict |
|---|---|
| AI meeting notes for a vertical (legal/health) | Strong but crowded; sales cycle through firms is slow; feature ceiling low |
| Review generation for clinics | High CAC through marketplaces, churny, compliance overhead |
| Sponsorship manager for newsletters | Tiny TAM; revenue cap per account |
| LLM eval/memory infra for developers | Devs build in-house; infra buyers don't pay for delight |
| **Hearth — recovery + expansion** | **Direct cash ROI, guilt-free spend, mission-critical once installed, under-served positioning, beautiful-UI wedge** |

---

## Product principles (what the UI demo shows)

1. **Recovery with dignity** — dunning emails written like a human note, not a bill collector's. Branded retry checkout your members actually trust.
2. **Smart retries first** — ~58% of failures recover via well-timed silent retries before anyone notices.
3. **Upgrade moments** — detect when a power user hits a limit, surface an AI-drafted pitch for one-click approval, bill instantly.
4. **A heartbeat monitor for revenue** — one calm dashboard: leaks found, rescued, at risk, upgraded.
5. **Design as the moat** — where rivals show tables, Hearth shows calm. The product *feels* like money being handled with care, because that is exactly what it does.

*Deliverables in this workspace: `idea-brief.md` (this file) + `index.html` — a fully interactive product site for Hearth (home, product tour, pricing) built as a **frosted-window interface**: a procedural winter atmosphere behind the glass (drifting multi-layer fog, three snow populations, rare warm blooms, condensation), a subtly displacing glass filter over the sky layer only, and frosted glass surfaces that sit at different depths. Each visit generates a slightly different winter scene; warm ivory/caramel palette throughout. See the product notes in this brief for the market math.*
