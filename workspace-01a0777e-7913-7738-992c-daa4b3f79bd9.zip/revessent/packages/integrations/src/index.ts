/**
 * SERVER-ONLY Stripe integration boundary (Phase 4A §8).
 *
 * `import "server-only"` makes it a BUILD ERROR for any client component to
 * reach this module through the React graph. Nothing in apps/web imports
 * this package; only @revessent/server services do.
 *
 * Exposed surface = the read-only gateway + safe error taxonomy. The Stripe
 * SDK, credentials and raw provider errors never leave this package.
 */
import "server-only";

import { stripeGateway } from "./stripe-client.js";
import type { StripeGateway } from "./gateway.js";

export type { StripeGateway, ProviderAccount, Page, ProviderCustomer, ProviderSubscription, ProviderInvoice, ListOptions } from "./gateway.js";
export { ProviderError, classifyProviderError, isProviderError } from "./errors.js";
export { normalizeSubscription, normalizeInvoice, normalizeCustomer, type StripeSubscriptionLike, type StripeInvoiceLike, type StripeCustomerLike } from "./normalize.js";
export {
  verifyStripeWebhook, describeStripeEvent, WEBHOOK_TOLERANCE_SECONDS, generateTestSignatureHeader,
  type StripeWebhookEvent, type WebhookVerifyCode
} from "./webhook.js";
export type { ProviderErrorCode } from "./errors.js";

const realGateway: StripeGateway = stripeGateway;
let active: StripeGateway = realGateway;

/** The gateway used by services (real stripe-node). */
export function getStripeGateway(): StripeGateway {
  return active;
}

/**
 * TEST-ONLY injection point: integration tests drive the boundary with
 * deterministic provider FIXTURES (§22 — live credentials unavailable in
 * this environment; the live success path is marked as such in the report).
 * Never call this from application code.
 */
export function setStripeGatewayForTests(gateway: StripeGateway): void {
  active = gateway;
}

/** TEST-ONLY: restore the real stripe-node gateway. */
export function resetStripeGateway(): void {
  active = realGateway;
}
