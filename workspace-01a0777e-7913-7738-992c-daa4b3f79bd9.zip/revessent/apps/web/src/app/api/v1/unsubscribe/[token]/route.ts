import { mutation } from "@/lib/api-route";

/** Notification preferences persist with the Phase 4 email stack. Honest no-op. */
export async function POST(req: Request, { params }: { params: Promise<{ token: string }> }) {
  return mutation(req, async () => {
    await params;
    return { state: "unknown" as const };
  });
}
