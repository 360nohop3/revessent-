import { requireOrgRole, expansionService } from "@revessent/server";
import { handle } from "@/lib/api-route";

export async function GET(req: Request, { params }: { params: Promise<{ slug: string; opportunityId: string }> }) {
  return handle(req, async () => {
    const ctx = await requireOrgRole(req.headers, (await params).slug, "view");
    return expansionService.getOpportunity(ctx, (await params).opportunityId);
  });
}
