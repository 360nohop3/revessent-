"use client";

import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { useState } from "react";
import { Button, Skeleton, Surface } from "@revessent/ui";
import { api } from "@/lib/api";

export function UnsubscribeTokenView() {
  const params = useParams<{ token: string }>();
  const qc = useQueryClient();
  const query = useQuery({ queryKey: ["subscriber", "unsubscribe", params.token], queryFn: () => api.subscriber.unsubscribe(params.token) });
  const [confirming, setConfirming] = useState(false);
  const [done, setDone] = useState(false);

  if (query.isLoading) return <Skeleton className="h-56 w-[min(480px,100%)]" />;

  return (
    <Surface level={2} className="w-[min(480px,100%)] p-6 text-center">
      <h1 className="text-[19px] font-bold text-ink">Stop these emails</h1>
      {done ? (
        <p role="status" className="mt-3 text-[14px] text-ink-2">
          Recorded in this demo only — the Phase 3 backend persists unsubscribe requests. In
          production you'd see a confirmation here once it's actually saved.
        </p>
      ) : (
        <>
          <p className="mt-2 text-[14px] text-ink-2">
            We'll stop sending recovery emails about this membership.
          </p>
          <div className="mt-4 flex justify-center gap-2.5">
            {confirming ? (
              <>
                <Button variant="ghost" size="sm" onClick={() => setConfirming(false)}>Keep emails</Button>
                <Button
                  variant="danger"
                  size="sm"
                  onClick={() => {
                    setDone(true);
                    void qc.invalidateQueries({ queryKey: ["subscriber", "unsubscribe", params.token] });
                  }}
                >
                  Confirm unsubscribe
                </Button>
              </>
            ) : (
              <Button size="sm" onClick={() => setConfirming(true)}>Unsubscribe</Button>
            )}
          </div>
        </>
      )}
    </Surface>
  );
}
